wget -nc https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv
